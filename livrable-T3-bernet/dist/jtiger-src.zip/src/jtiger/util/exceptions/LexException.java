package jtiger.util.exceptions;

/** 
 * LexException provides a specific Exception class for 
 * Lexer Exceptions.
 *
 * @author  Pablo Oliveira
 */ 
public class LexException extends Exception {}
