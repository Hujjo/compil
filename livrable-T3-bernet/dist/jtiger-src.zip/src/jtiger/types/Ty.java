package jtiger.types;
public abstract class Ty {
}
