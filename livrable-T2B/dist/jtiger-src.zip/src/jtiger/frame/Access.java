package jtiger.frame;
public interface Access {
}
