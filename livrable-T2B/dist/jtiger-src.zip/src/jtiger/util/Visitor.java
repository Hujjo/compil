package jtiger.util;

/**
 * Base type for visitor classes.
 * 
 * @author Pablo Oliveira
 */
public abstract class Visitor {}
