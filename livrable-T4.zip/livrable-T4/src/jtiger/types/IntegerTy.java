package jtiger.types;

public class IntegerTy extends Ty {
}
