package jtiger.types;

public final class NilTy extends Ty {
}
