package jtiger.types;

public class StringTy extends Ty {
}
