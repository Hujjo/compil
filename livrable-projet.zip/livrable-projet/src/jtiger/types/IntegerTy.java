package jtiger.types;

public class IntegerTy extends Ty {

    public String toString () {
        return "IntegerTy";
    }

}
