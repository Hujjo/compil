package jtiger.types;

public class StringTy extends Ty {

    public String toString() {
        return "StringTy";
    }

}
