package jtiger.types;

final class ErrorTy extends Ty {
}
