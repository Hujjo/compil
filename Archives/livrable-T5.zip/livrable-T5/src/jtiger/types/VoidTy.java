package jtiger.types;

public final class VoidTy extends Ty {

    public String toString() {
        return "VoidTy";
    }

}
